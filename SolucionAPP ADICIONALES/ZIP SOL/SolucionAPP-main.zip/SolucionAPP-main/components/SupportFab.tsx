import React from 'react';
import { MessageCircle } from 'lucide-react';

const SupportFab: React.FC = () => {
  const handleSupportClick = () => {
    window.open('https://wa.me/5492213537852', '_blank');
  };

  return (
    <button
      onClick={handleSupportClick}
      className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-2xl shadow-lg z-50 flex items-center justify-center"
      aria-label="Soporte WhatsApp"
    >
      <MessageCircle size={26} />
    </button>
  );
};
export default SupportFab;
