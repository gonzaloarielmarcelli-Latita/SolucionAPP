import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, MessageCircle, ShieldCheck, MapPin } from 'lucide-react';
import { getProsByCategory } from '../services/dataService';
import { UserPro } from '../types';
import SupportFab from './SupportFab';

const ServiceListScreen: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const navigate = useNavigate();
  const [pros, setPros] = useState<UserPro[]>([]);
  const categoryName = decodeURIComponent(category || '');

  useEffect(() => {
    getProsByCategory(categoryName).then(setPros);
  }, [categoryName]);

  const handleContact = (pro: UserPro) => {
    const message = `Hola SolucionAPP, me interesa contratar a ${pro.name} (${pro.category}).`;
    window.open(`https://wa.me/5492213537852?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 pb-32">
      <div className="bg-white sticky top-0 z-20 px-4 py-4 flex items-center gap-4 border-b border-gray-100 shadow-sm">
        <button onClick={() => navigate('/client')}><ArrowLeft size={20} /></button>
        <h1 className="text-lg font-bold">{categoryName}</h1>
      </div>

      <main className="p-4 flex flex-col gap-4">
        <div className="text-center py-6">
            <ShieldCheck size={48} className="text-blue-500 mx-auto mb-2" />
            <h2 className="text-3xl font-extrabold text-slate-900">Tu seguridad es prioridad</h2>
            <p className="text-sm text-gray-500 mt-2">Entrevistamos personalmente a cada profesional, verificamos sus antecedentes penales y validamos su matrícula.</p>
        </div>

        {pros.map((pro) => (
          <div key={pro.id} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex gap-4">
                <img src={pro.photoUrl} alt={pro.name} className="w-16 h-16 rounded-xl bg-gray-200 object-cover" />
                <div>
                    <h3 className="font-bold text-lg">{pro.name}</h3>
                    <div className="flex items-center gap-1 text-yellow-600 font-bold text-xs"><Star size={12} fill="currentColor" /> 4.9</div>
                    <div className="flex items-center gap-1 text-gray-400 text-xs mt-1"><MapPin size={12} /> A 2km</div>
                </div>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-50 flex justify-between items-center">
                <span className="text-xs text-gray-400 font-mono">{pro.licenseId}</span>
                <button onClick={() => handleContact(pro)} className="bg-green-500 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2"><MessageCircle size={16} /> Contactar</button>
            </div>
          </div>
        ))}
      </main>
      <SupportFab />
    </div>
  );
};
export default ServiceListScreen;
